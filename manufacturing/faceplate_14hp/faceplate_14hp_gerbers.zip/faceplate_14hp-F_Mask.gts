%TF.GenerationSoftware,KiCad,Pcbnew,9.0.2+dfsg-1*%
%TF.CreationDate,2026-11-20T20:09:39+00:00*%
%TF.ProjectId,faceplate_14hp,66616365-706c-4617-9465-5f313468702e,rev?*%
%TF.SameCoordinates,Original*%
%TF.FileFunction,Soldermask,Top*%
%TF.FilePolarity,Negative*%
%FSLAX46Y46*%
G04 Gerber Fmt 4.6, Leading zero omitted, Abs format (unit mm)*
G04 Created by KiCad (PCBNEW 9.0.2+dfsg-1) date 2026-11-20 20:09:39*
%MOMM*%
%LPD*%
G01*
G04 APERTURE LIST*
%ADD10C,3.200000*%
G04 APERTURE END LIST*
D10*
%TO.C,MH2*%
X63380000Y-3000000D03*
%TD*%
%TO.C,MH1*%
X7500000Y-3000000D03*
%TD*%
%TO.C,MH4*%
X63380000Y-125500000D03*
%TD*%
%TO.C,MH3*%
X7500000Y-125500000D03*
%TD*%
M02*
